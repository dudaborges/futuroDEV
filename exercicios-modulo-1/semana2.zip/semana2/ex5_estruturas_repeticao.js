let num = [5, 8, 2, 9, 3]

for(var indice = 0; indice <= num.length; indice++){
    console.log(`A posição ${indice} tem o valor ${num[indice]}`)
}