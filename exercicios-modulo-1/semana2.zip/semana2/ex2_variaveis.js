let nome = "Maria"
let sobrenome = "Borges"
let idade = 17
let bairro = "Ratones"
let turma = "Santinho"