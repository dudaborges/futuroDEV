let n1 = 7
let n2 = 9
let n3 = 4
let media = (n1 + n2 + n3) / 3

if (media >= 7){
    console.log('Aprovado!')
}else{
    console.log('Reprovado!')
}