let nome = "maria"

console.log(`o nome ${nome} tem ${nome.length} caracteres`)