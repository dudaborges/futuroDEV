for(let i = 0; i <= 100; i++){
    if(i % 5 != 0){
        console.log(i)
    }
}

