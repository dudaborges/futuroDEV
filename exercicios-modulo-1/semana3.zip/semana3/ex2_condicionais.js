let num = 6

if(num % 3 == 0){
    console.log(`O número ${num} é múltiplo de 3`)
}else{
    console.log(`O número ${num} não é múltiplo de 3`)
}